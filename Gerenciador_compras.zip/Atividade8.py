# Função para adicionar um produto à lista
def adicionar_produto(lista):
    nome = input("Digite o nome do produto: ")
    quantidade = int(input("Digite a quantidade: "))
    valor_unitario = float(input("Digite o valor unitário: "))
    total_produto = quantidade * valor_unitario
    lista.append({"produto": nome, "quantidade": quantidade, "valor": valor_unitario, "total": total_produto})
    print("Produto adicionado com sucesso.")

# Função para exibir a lista de produtos
def ver_lista(lista):
    if lista:
        print("Lista de produtos:")
        for produto in lista:
            print(f"Nome: {produto['produto']}, Quantidade: {produto['quantidade']}, Valor Unitário: {produto['valor']}, Total: {produto['total']}")
        valor_total = sum(produto['total'] for produto in lista)
        print(f"Valor total de todos os produtos: {valor_total}")
    else:
        print("A lista de produtos está vazia.")

# Função para atualizar as informações de um produto
def atualizar_produto(lista):
    nome = input("Digite o nome do produto que deseja atualizar: ")
    for produto in lista:
        if produto['produto'] == nome:
            produto['produto'] = input("Digite o novo nome do produto: ")
            produto['quantidade'] = int(input("Digite a nova quantidade: "))
            produto['valor'] = float(input("Digite o novo valor unitário: "))
            produto['total'] = produto['quantidade'] * produto['valor']
            print("Produto atualizado com sucesso.")
            return
    print("Produto não encontrado.")

# Função para remover um produto da lista
def remover_produto(lista):
    nome = input("Digite o nome do produto que deseja remover: ")
    for produto in lista:
        if produto['produto'] == nome:
            lista.remove(produto)
            print("Produto removido com sucesso.")
            return
    print("Produto não encontrado.")

if __name__ == "__main__":
    lista_produtos = []
    while True:
        print("\nOpções:")
        print("1. Adicionar produto")
        print("2. Ver lista de produtos")
        print("3. Atualizar produto")
        print("4. Remover produto")
        print("5. Encerrar programa")

        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            adicionar_produto(lista_produtos)
        elif opcao == "2":
            ver_lista(lista_produtos)
        elif opcao == "3":
            atualizar_produto(lista_produtos)
        elif opcao == "4":
            remover_produto(lista_produtos)
        elif opcao == "5":
            print("Encerrando programa...")
            break
        else:
            print("Opção inválida. Por favor, escolha uma opção válida.")
